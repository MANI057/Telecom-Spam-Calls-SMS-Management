using SpamComplaintManagement.Business.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace SpamComplaintManagement.Web.Pages.Account;

public class RegisterModel : PageModel
{
    private readonly IAccountService _accountService;

    public RegisterModel(IAccountService accountService) => _accountService = accountService;

    [BindProperty, Required, StringLength(100, MinimumLength = 2)]
    public string FullName { get; set; } = "";

    [BindProperty, Required, EmailAddress]
    public string Email { get; set; } = "";

    [BindProperty, Required, MinLength(6), DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public string ErrorMessage { get; set; } = "";

    public void OnGet() { }

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid) return Page();

        var result = _accountService.Register(FullName, Email, Password);
        if (!result.Success)
        {
            ErrorMessage = result.Message;
            return Page();
        }

        return RedirectToPage("/Account/Login");
    }
}
