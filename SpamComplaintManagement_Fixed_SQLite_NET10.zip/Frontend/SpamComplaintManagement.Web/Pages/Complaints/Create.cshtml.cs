using SpamComplaintManagement.Business.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace SpamComplaintManagement.Web.Pages.Complaints;

public class CreateModel : PageModel
{
    private readonly IComplaintService _service;
    public CreateModel(IComplaintService service) => _service = service;

    [BindProperty, Required] public string SpamType { get; set; } = "SMS";
    [BindProperty, Required] public string SpamNumber { get; set; } = "";
    [BindProperty, Required] public string Sender { get; set; } = "";
    [BindProperty, Required] public string CommunicationDetails { get; set; } = "";

    public string ErrorMessage { get; set; } = "";

    public IActionResult OnGet()
    {
        if (HttpContext.Session.GetInt32("UserId") == null)
            return RedirectToPage("/Account/Login");
        return Page();
    }

    public IActionResult OnPost()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null) return RedirectToPage("/Account/Login");
        if (!ModelState.IsValid) return Page();

        var result = _service.Create(userId.Value, SpamType, SpamNumber, Sender, CommunicationDetails);
        if (!result.Success)
        {
            ErrorMessage = result.Message;
            return Page();
        }

        return RedirectToPage("/Complaints/Details", new { id = result.Complaint!.ComplaintId });
    }
}
