using SpamComplaintManagement.Business.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SpamComplaintManagement.Data.Models;

namespace SpamComplaintManagement.Web.Pages.Complaints;

public class IndexModel : PageModel
{
    private readonly IComplaintService _service;
    public IndexModel(IComplaintService service) => _service = service;
    public List<Complaint> Complaints { get; set; } = new();

    public IActionResult OnGet()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null) return RedirectToPage("/Account/Login");
        Complaints = _service.GetForUser(userId.Value);
        return Page();
    }
}
