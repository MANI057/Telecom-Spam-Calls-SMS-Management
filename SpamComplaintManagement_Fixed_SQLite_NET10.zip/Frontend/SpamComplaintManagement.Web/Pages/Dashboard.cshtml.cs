using SpamComplaintManagement.Business.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SpamComplaintManagement.Data.Models;

namespace SpamComplaintManagement.Web.Pages;

public class DashboardModel : PageModel
{
    private readonly IComplaintService _complaintService;
    public DashboardModel(IComplaintService complaintService) => _complaintService = complaintService;

    public string UserName { get; set; } = "";
    public int ComplaintCount { get; set; }
    public string LatestStatus { get; set; } = "—";
    public List<Complaint> Complaints { get; set; } = new();

    public IActionResult OnGet()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null) return RedirectToPage("/Account/Login");

        UserName = HttpContext.Session.GetString("UserName") ?? "User";
        Complaints = _complaintService.GetForUser(userId.Value);
        ComplaintCount = Complaints.Count;
        LatestStatus = Complaints.FirstOrDefault()?.Status ?? "—";
        return Page();
    }
}
