using Microsoft.EntityFrameworkCore;
using SpamComplaintManagement.Business.Interfaces;
using SpamComplaintManagement.Business.Services;
using SpamComplaintManagement.Data;
using SpamComplaintManagement.Data.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? "Data Source=spamcomplaintmanagement.db";

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite(connectionString));

// Complaint data remains in the existing repository for this version.
builder.Services.AddSingleton<InMemoryRepository>();
builder.Services.AddScoped<IAccountService, AccountService>();
builder.Services.AddScoped<IComplaintService, ComplaintService>();

var app = builder.Build();

// Create the SQLite database and LoginCredentials table automatically on first run.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.EnsureCreated();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.MapRazorPages();

app.Run();
