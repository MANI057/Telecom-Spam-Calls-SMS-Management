using SpamComplaintManagement.Data.Models;

namespace SpamComplaintManagement.Business.Interfaces;

public interface IAccountService
{
    (bool Success, string Message, User? User) Register(string fullName, string email, string password);
    User? Login(string email, string password);
}
