using SpamComplaintManagement.Data.Models;

namespace SpamComplaintManagement.Business.Interfaces;

public interface IComplaintService
{
    (bool Success, string Message, Complaint? Complaint) Create(
        int userId, string spamType, string spamNumber, string sender, string details);

    List<Complaint> GetForUser(int userId);
    Complaint? Get(string complaintId, int userId);
}
