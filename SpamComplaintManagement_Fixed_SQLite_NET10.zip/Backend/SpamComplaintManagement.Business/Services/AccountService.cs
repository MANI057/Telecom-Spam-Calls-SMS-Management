using Microsoft.EntityFrameworkCore;
using SpamComplaintManagement.Business.Interfaces;
using SpamComplaintManagement.Data;
using SpamComplaintManagement.Data.Models;

namespace SpamComplaintManagement.Business.Services;

public class AccountService : IAccountService
{
    private readonly ApplicationDbContext _db;

    public AccountService(ApplicationDbContext db) => _db = db;

    public (bool Success, string Message, User? User) Register(
        string fullName, string email, string password)
    {
        if (string.IsNullOrWhiteSpace(fullName) ||
            string.IsNullOrWhiteSpace(email) ||
            string.IsNullOrWhiteSpace(password))
            return (false, "All fields are required.", null);

        if (password.Length < 6)
            return (false, "Password must contain at least 6 characters.", null);

        fullName = fullName.Trim();
        email = email.Trim();

        var existingUser = _db.LoginCredentials
            .FirstOrDefault(x => x.Email.ToLower() == email.ToLower());

        if (existingUser != null)
            return (false, "An account with this email already exists.", null);

        var user = new User
        {
            FullName = fullName,
            Email = email,
            PasswordHash = PasswordService.Hash(password),
            CreatedAt = DateTime.UtcNow
        };

        _db.LoginCredentials.Add(user);
        _db.SaveChanges();

        return (true, "Registration successful.", user);
    }

    public User? Login(string email, string password)
    {
        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            return null;

        var user = _db.LoginCredentials
            .FirstOrDefault(x => x.Email.ToLower() == email.Trim().ToLower());

        return user != null && PasswordService.Verify(password, user.PasswordHash)
            ? user
            : null;
    }
}
