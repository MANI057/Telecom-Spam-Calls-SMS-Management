using SpamComplaintManagement.Business.Interfaces;
using SpamComplaintManagement.Data.Models;
using SpamComplaintManagement.Data.Repositories;

namespace SpamComplaintManagement.Business.Services;

public class ComplaintService : IComplaintService
{
    private readonly InMemoryRepository _repo;

    public ComplaintService(InMemoryRepository repo) => _repo = repo;

    public (bool Success, string Message, Complaint? Complaint) Create(
        int userId, string spamType, string spamNumber, string sender, string details)
    {
        if (string.IsNullOrWhiteSpace(spamType) ||
            string.IsNullOrWhiteSpace(spamNumber) ||
            string.IsNullOrWhiteSpace(sender) ||
            string.IsNullOrWhiteSpace(details))
            return (false, "Please complete all complaint fields.", null);

        var complaint = new Complaint
        {
            ComplaintId = $"CMP-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid():N}"[..17].ToUpperInvariant(),
            UserId = userId,
            SpamType = spamType,
            SpamNumber = spamNumber.Trim(),
            Sender = sender.Trim(),
            CommunicationDetails = details.Trim(),
            Status = "Submitted"
        };

        complaint.History.Add(new ComplaintStatusHistory { Status = "Submitted" });
        return (true, "Complaint submitted successfully.", _repo.AddComplaint(complaint));
    }

    public List<Complaint> GetForUser(int userId) => _repo.GetComplaintsByUser(userId);

    public Complaint? Get(string complaintId, int userId) => _repo.GetComplaintForUser(complaintId, userId);
}
