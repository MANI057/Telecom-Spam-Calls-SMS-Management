# Spam Complaint Management - ASP.NET Core Razor Pages (.NET 10)

## Structure

Frontend and backend are separated into different folders.

- `Frontend/SpamComplaintManagement.Web` - Razor Pages UI and web startup
- `Backend/SpamComplaintManagement.Business` - business logic/services
- `Backend/SpamComplaintManagement.Data` - models and repository/data access

## Run in VS Code

From the solution root:

```powershell
dotnet restore
dotnet build
dotnet run --project ".\Frontend\SpamComplaintManagement.Web\SpamComplaintManagement.Web.csproj"
```

Or:

```powershell
cd ".\Frontend\SpamComplaintManagement.Web"
dotnet run
```
